#include<stdio.h>

int function(){
    printf("Hello World!\n");
    return 2;
}